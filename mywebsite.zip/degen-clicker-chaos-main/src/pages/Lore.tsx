
import React from 'react';
import TerminalFooter from '@/components/TerminalFooter';

const Lore = () => {
  return (
    <div className="retro-container overflow-auto">
      {/* Scanline effect */}
      <div className="scanline"></div>
      
      {/* Main Content */}
      <div className="w-full max-w-3xl mx-auto mb-12 px-4">
        <h1 className="text-4xl md:text-6xl font-press-start mb-12 glitch-text text-center"
            data-text="📜 The Lore">
          📜 The Lore
        </h1>
        
        <div className="prose prose-lg max-w-none terminal-text space-y-6">
          <p>In the beginning, there was no button. Only chaos.</p>
          
          <p>Then came a whisper across the memechain. A sacred UI. A clickable artifact of unknown origin.</p>
          
          <p>Some say it's powered by a quantum Shiba. Others believe it's a cursed hardware wallet from 2017. All we know is—you click it, and things happen. Sometimes.</p>
          
          <p>The Degen Button is not a game. It's not a utility. It's a test of endurance, meaninglessness, and pure ape energy.</p>
          
          <p>So click. Click for no reason. Click for fate. Click because that's all we have left.</p>
          
          <p className="text-xl font-bold animate-pulse">Glory awaits the degens who dare to believe in absolutely nothing.</p>
        </div>
      </div>
      
      {/* Footer */}
      <TerminalFooter />
    </div>
  );
};

export default Lore;
