
import React, { useState } from 'react';
import TerminalFooter from '@/components/TerminalFooter';
import { toast } from '@/hooks/use-toast';
import { Check, Clock, FileX } from "lucide-react";

const ClickToken = () => {
  const [isClicked, setIsClicked] = useState(false);
  
  const handleAirdropClick = () => {
    setIsClicked(true);
    toast({
      title: "$CLICK Airdrop",
      description: "Not ready yet. Keep clicking.",
      duration: 5000,
    });
  };
  
  return (
    <div className="retro-container overflow-auto">
      {/* Scanline effect */}
      <div className="scanline"></div>
      
      {/* Main Content */}
      <div className="w-full max-w-3xl mx-auto mb-12 px-4">
        <h1 className="text-4xl md:text-6xl font-press-start mb-8 glitch-text text-center"
            data-text="$CLICK Token">
          $CLICK Token
        </h1>
        <h2 className="text-xl md:text-2xl font-vt323 mb-12 text-center">
          Powered by Clicks, Fueled by Cope
        </h2>
        
        <div className="prose prose-lg max-w-none terminal-text space-y-10">
          <div className="bg-black/40 border border-green-500/30 p-6 rounded-md">
            <p className="text-xl mb-6">This isn't just a button anymore. It's an economy.</p>
            
            <p>$CLICK is the official token of degeneracy. Built on the principle of Proof of Click™. No presale. No roadmap worth trusting. Just vibes and finger cramps.</p>
          </div>
          
          <div className="bg-black/40 border border-green-500/30 p-6 rounded-md">
            <h3 className="text-2xl font-vt323 mb-4">Tokenomics:</h3>
            <ul className="space-y-2 list-none pl-0">
              <li className="flex items-start">
                <span className="text-2xl mr-2">🟢</span> 
                <span>90% – Fair Launch to the community</span>
              </li>
              <li className="flex items-start">
                <span className="text-2xl mr-2">🔒</span> 
                <span>10% – Locked by devs (we're degen, not evil… probably)</span>
              </li>
              <li className="flex items-start">
                <span className="text-2xl mr-2">🚫</span> 
                <span>0% VC</span>
              </li>
              <li className="flex items-start">
                <span className="text-2xl mr-2">🐸</span> 
                <span>100% Meme Utility</span>
              </li>
            </ul>
          </div>
          
          <div className="bg-black/40 border border-green-500/30 p-6 rounded-md">
            <h3 className="text-2xl font-vt323 mb-4">Roadmap:</h3>
            <ul className="space-y-3 list-none pl-0">
              <li className="flex items-start">
                <span className="mr-2"><Check size={18} className="text-green-500" /></span> 
                <span>Launch The Degen Button</span>
              </li>
              <li className="flex items-start">
                <span className="mr-2"><Check size={18} className="text-green-500" /></span> 
                <span>Add whitelist feature (click 100x to unlock)</span>
              </li>
              <li className="flex items-start">
                <span className="mr-2"><Check size={18} className="text-green-500" /></span> 
                <span>Drop random chaos every 1k clicks</span>
              </li>
              <li className="flex items-start">
                <span className="mr-2"><Clock size={18} className="text-yellow-500" /></span> 
                <span>Launch $CLICK Token</span>
              </li>
              <li className="flex items-start">
                <span className="mr-2"><Clock size={18} className="text-yellow-500" /></span> 
                <span>Integrate meme-based DAO governance</span>
              </li>
              <li className="flex items-start">
                <span className="mr-2"><Clock size={18} className="text-yellow-500" /></span> 
                <span>Use clicks to vote on dumb stuff</span>
              </li>
              <li className="flex items-start">
                <span className="mr-2"><FileX size={18} className="text-red-500" /></span> 
                <span>Build something useful</span>
              </li>
            </ul>
          </div>
          
          {/* CTA Button */}
          <div className="flex justify-center mt-10">
            <button 
              onClick={handleAirdropClick}
              disabled={isClicked}
              className={`px-6 py-3 bg-green-600 text-white font-press-start text-lg rounded 
                        hover:bg-green-500 transition-colors animate-pulse-glow
                        ${isClicked ? 'opacity-50 cursor-not-allowed' : ''}`}
            >
              CLAIM AIRDROP
            </button>
          </div>
        </div>
      </div>
      
      {/* Footer */}
      <TerminalFooter />
    </div>
  );
};

export default ClickToken;
