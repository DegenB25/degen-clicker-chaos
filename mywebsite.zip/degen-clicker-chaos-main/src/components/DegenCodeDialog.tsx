
import React from "react";
import { Dialog, DialogContent } from "@/components/ui/dialog";

interface DegenCodeDialogProps {
  open: boolean;
  code: string;
  onOpenChange: (open: boolean) => void;
}

const DegenCodeDialog: React.FC<DegenCodeDialogProps> = ({ open, code, onOpenChange }) => (
  <Dialog open={open} onOpenChange={onOpenChange}>
    <DialogContent className="bg-black border-2 border-green-500 text-green-500 font-vt323 max-w-md">
      <div className="p-6 text-center">
        <h3 className="text-xl mb-4 terminal-text">You've found the DEGEN CODE</h3>
        <div className="bg-green-900/20 border border-green-500 p-4 mb-4">
          <span className="text-3xl font-mono tracking-wide">{code}</span>
        </div>
        <p className="terminal-text">
          Post it on Twitter and tag <span className="text-blue-400">@degenbutton</span>
        </p>
      </div>
    </DialogContent>
  </Dialog>
);

export default DegenCodeDialog;
