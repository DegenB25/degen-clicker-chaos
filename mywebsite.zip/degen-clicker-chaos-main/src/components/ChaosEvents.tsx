
import React, { useEffect, useState } from 'react';

interface ChaosEventsProps {
  isActive: boolean;
  onEnd: () => void; // Changed from accepting a MouseEvent to no parameters
}

const ChaosEvents: React.FC<ChaosEventsProps> = ({ isActive, onEnd }) => {
  const [eventType, setEventType] = useState<string>('');
  const [fallingItems, setFallingItems] = useState<Array<{ id: number; x: number }>>([]);
  const chaosSound = React.useRef<HTMLAudioElement | null>(null);
  
  useEffect(() => {
    chaosSound.current = new Audio('/chaos.mp3');
  }, []);

  useEffect(() => {
    if (isActive) {
      // Play chaos sound
      if (chaosSound.current) {
        chaosSound.current.currentTime = 0;
        chaosSound.current.play().catch(e => console.log('Audio play error:', e));
      }
      
      // Pick a random event
      const events = ['meme', 'bsod', 'rain', 'text'];
      const randomEvent = events[Math.floor(Math.random() * events.length)];
      setEventType(randomEvent);
      
      // Create falling items if rain event
      if (randomEvent === 'rain') {
        const items = [];
        for (let i = 0; i < 20; i++) {
          items.push({
            id: i,
            x: Math.random() * window.innerWidth
          });
        }
        setFallingItems(items);
      }
      
      // End the event after some time
      const duration = randomEvent === 'bsod' ? 5000 : 3000;
      setTimeout(() => {
        setEventType('');
        setFallingItems([]);
        onEnd();
      }, duration);
    }
  }, [isActive, onEnd]);

  if (!isActive || !eventType) return null;

  return (
    <div className="chaos-event">
      {eventType === 'meme' && (
        <div className="fixed inset-0 bg-black/90 flex items-center justify-center z-40">
          <div className="text-center">
            <h2 className="text-5xl md:text-7xl font-press-start text-green-500 mb-4 animate-glitch">
              SUCH CLICK
            </h2>
            <p className="text-3xl md:text-5xl font-vt323 text-green-500 animate-glitch">
              VERY DEGEN
            </p>
          </div>
        </div>
      )}
      
      {eventType === 'bsod' && (
        <div className="bsod">
          <h2 className="text-3xl md:text-5xl font-vt323 mb-8">CRITICAL ERROR</h2>
          <p className="text-xl md:text-2xl font-vt323 mb-4 max-w-2xl text-center">
            A problem has been detected and your brain has been shut down to prevent damage to your wallet.
          </p>
          <p className="text-xl md:text-2xl font-vt323 mb-8">
            ERROR: TOO_MANY_CLICKS_DETECTED
          </p>
          <p className="text-md md:text-xl font-vt323">
            Technical information: STOP: 0x000000ED (0x0000000, 0x0000000, 0x0000000, 0x0000000)
          </p>
        </div>
      )}
      
      {eventType === 'rain' && (
        <>
          {fallingItems.map(item => (
            <div
              key={item.id}
              className="falling-item"
              style={{
                left: `${item.x}px`,
                animationDuration: `${Math.random() * 3 + 2}s`,
                animationDelay: `${Math.random() * 2}s`
              }}
            >
              <img src="/coin.png" alt="ETH" className="w-full h-full" />
            </div>
          ))}
        </>
      )}
      
      {eventType === 'text' && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-40">
          <h1 className="text-4xl md:text-8xl font-press-start text-green-500 animate-text-flicker">
            WE ARE THE CLICK
          </h1>
        </div>
      )}
    </div>
  );
};

export default ChaosEvents;
