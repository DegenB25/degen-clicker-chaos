
import React, { useEffect, useState } from 'react';
import { Dialog, DialogContent, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

interface DegenFortuneProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const fortunePredictions = [
  "You will ape into a rug and feel no regret.",
  "Buy top, sell bottom. As foretold.",
  "You are not early. But you are loud.",
  "Degen path unclear. Try clicking harder.",
  "You clicked 250 times. There is no reward.",
  "Your portfolio will go down before it goes down more.",
  "Strong hands, weak strategy. This is the way.",
  "The chart you're watching is watching you back.",
  "Fortune favors the based, not the brave.",
  "Next bull run will come when you finally sell.",
  "Your seed phrase is being memorized by someone else.",
  "A 100x opportunity awaits. You will miss it for a 10x loss.",
  "NFTs you mint now will be worthless. But so will everything else.",
  "Learn to love the red candles. They're your only friends now."
];

const DegenFortune: React.FC<DegenFortuneProps> = ({ open, onOpenChange }) => {
  const [fortune, setFortune] = useState("");
  const [terminalText, setTerminalText] = useState("");
  const [showCursor, setShowCursor] = useState(true);
  
  useEffect(() => {
    if (open) {
      const randomFortune = fortunePredictions[Math.floor(Math.random() * fortunePredictions.length)];
      setFortune(randomFortune);
      
      // Typewriter effect
      let i = 0;
      setTerminalText("");
      const typeInterval = setInterval(() => {
        if (i < randomFortune.length) {
          setTerminalText(prev => prev + randomFortune.charAt(i));
          i++;
        } else {
          clearInterval(typeInterval);
        }
      }, 50);
      
      // Blinking cursor
      const cursorInterval = setInterval(() => {
        setShowCursor(prev => !prev);
      }, 500);
      
      return () => {
        clearInterval(typeInterval);
        clearInterval(cursorInterval);
      }
    }
  }, [open]);
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-black border-2 border-green-500 text-green-500 font-vt323 max-w-md p-0 overflow-hidden">
        <div className="bg-green-900/30 p-1 flex justify-between items-center border-b border-green-500">
          <span className="text-sm">DEGEN-PROPHECY.EXE</span>
          <div className="flex gap-1">
            <span className="w-3 h-3 rounded-full bg-red-500"></span>
            <span className="w-3 h-3 rounded-full bg-yellow-500"></span>
            <span className="w-3 h-3 rounded-full bg-green-500"></span>
          </div>
        </div>
        
        <div className="p-6 min-h-[180px] bg-terminal bg-opacity-90 flex flex-col justify-center">
          <div className="terminal-line font-mono text-lg my-4">INITIALIZING PROPHECY MODULE...</div>
          <div className="terminal-line font-mono text-lg my-4">ANALYZING CLICK PATTERN...</div>
          <div className="terminal-line font-mono text-lg my-4">DEGENERATE FUTURE PREDICTED:</div>
          <div className="my-4 text-xl font-bold ml-6">
            {terminalText}{showCursor ? "▓" : ""}
          </div>
        </div>
        
        <DialogFooter className="bg-green-900/30 border-t border-green-500 p-2">
          <Button 
            onClick={() => onOpenChange(false)}
            className="bg-black hover:bg-green-900 text-green-500 border border-green-500"
          >
            CLOSE TERMINAL [ESC]
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default DegenFortune;
