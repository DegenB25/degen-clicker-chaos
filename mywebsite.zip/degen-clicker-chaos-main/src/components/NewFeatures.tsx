
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const features = [
  {
    title: "3D Button",
    description: "Experience the new dimension of clicking with our 3D DEGEN button"
  },
  {
    title: "Click Counter",
    description: "Track your progress with the glitching counter"
  },
  {
    title: "Whitelist Access",
    description: "Reach 100 clicks to unlock whitelist registration"
  }
];

const NewFeatures = () => {
  return (
    <section className="max-w-4xl mx-auto px-4 py-8">
      <h2 className="text-2xl md:text-3xl font-press-start mb-6 glitch-text" data-text="NEW FEATURES">
        NEW FEATURES
      </h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {features.map((feature, index) => (
          <Card key={index} className="bg-black border-green-500 hover:border-purple-500 transition-colors">
            <CardHeader>
              <CardTitle className="text-xl font-vt323 text-green-500">{feature.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="font-vt323 text-green-400/80">{feature.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </section>
  );
};

export default NewFeatures;
