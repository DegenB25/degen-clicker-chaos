
import React, { useState } from 'react';
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";

interface WhitelistFormProps {
  onSubmit: (email: string) => void;
}

const WhitelistForm: React.FC<WhitelistFormProps> = ({ onSubmit }) => {
  const [email, setEmail] = useState('');
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.includes('@')) {
      toast({
        title: "Invalid Email",
        description: "Please enter a valid email address",
        variant: "destructive"
      });
      return;
    }
    onSubmit(email);
    setEmail('');
    toast({
      title: "Welcome to the whitelist!",
      description: "You're officially based.",
    });
  };

  return (
    <form onSubmit={handleSubmit} className="flex flex-col items-center gap-4 mb-8">
      <div className="whitelist-banner animate-pulse-glow mb-4">
        <p className="text-xl md:text-2xl font-press-start text-center mb-2">
          YOU'VE CLICKED 100x. YOU'VE MADE IT.
        </p>
        <p className="text-lg md:text-xl font-vt323 text-center text-red-500">
          GET WHITELISTED OR MISS OUT.
        </p>
      </div>
      <div className="flex gap-2">
        <Input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="your@email.com"
          className="w-64 font-vt323 text-lg bg-black border-green-500"
        />
        <button 
          type="submit"
          className="px-4 py-2 bg-green-600 text-white font-press-start text-sm rounded 
                   hover:bg-green-500 transition-colors animate-pulse-glow"
        >
          JOIN WHITELIST
        </button>
      </div>
    </form>
  );
};

export default WhitelistForm;
