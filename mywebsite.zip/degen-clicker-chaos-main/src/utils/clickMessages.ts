
// Pool of click reaction messages
export const clickMessages = [
  // Degen Culture
  "Certified clicker.",
  "This button slaps.",
  "Click harder, degen.",
  "Your girlfriend is watching.",
  "Proof of click > Proof of stake",
  "GM to clicking only",
  "WAGMI (We All Get Mouse Injuries)",
  "Clicking is not a crime",
  "Few understand clicking",
  "Click it till you make it",
  "Based clicker detected",
  "Clicks only go up",
  "In click we trust",
  "Diamond clicks",
  "Click SDK when?",
  "Clicking to the moon 🚀",
  "Clickoor spotted",
  "Click's not dead",
  "Just click it anon",
  "Click first, ask later",
  "Bullish on clicks",
  "Click max activated",
  "Click farming season",
  "Click or ngmi",
  "Still clicking?",
  "Click it again ser",
  "Top signal: still clicking",
  "Click fundamentals strong",
  "High click energy",
  "Click thesis intact",
  // Memes
  "Sir, this is a clicking Wendy's",
  "Click goes brrrr",
  "Such click, much wow",
  "One of us! One of us!",
  "I like the click",
  "Not clicking advice",
  "Click it. Click it now.",
  "Born to click",
  "Click is love. Click is life.",
  "Clicking guarantees citizenship",
  // Funny
  "RIP mouse warranty",
  "Mouse durability test in progress",
  "Click or real job",
  "Clicks only, no utility",
  "Click first, think never",
  "Your FBI agent approves",
  "Click responsibility",
  "Mom said it's my turn to click",
  "Clicking instead of sleeping",
  "Touch grass? Click grass.",
  // Easter Eggs (rare)
  "You found the rare click message!",
  "Click singularity achieved",
  "The prophecy foretold this click",
  "Click Council approves",
  "Clicking guarantees citizenship"
];

// Pool of miss click messages
export const missClickMessages = [
  "That's not the button.",
  "You missed.",
  "Try again, maybe?",
  "Button.exe not found here",
  "404: Button not found",
  "Close, but no button",
  "The button is lonely without you",
  "Your aim needs work, anon",
  "Wrong coordinates, ser",
  "Nice try, keep practicing",
  "Button't"
];

// Utility to get random message without recent repeats
let recentMessages: string[] = [];
export const getRandomMessage = (messages: string[]) => {
  const availableMessages = messages.filter(msg => !recentMessages.includes(msg));
  if (availableMessages.length === 0) {
    recentMessages = []; // Reset if all messages have been used
    return messages[Math.floor(Math.random() * messages.length)];
  }
  const message = availableMessages[Math.floor(Math.random() * availableMessages.length)];
  recentMessages = [...recentMessages, message].slice(-10); // Keep last 10 messages
  return message;
};

// Generate a random 9-digit code
export const generateDegenCode = () => {
  return Math.random().toString().substring(2, 11);
};
