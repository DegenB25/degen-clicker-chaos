import React, { useState, useRef, useEffect } from 'react';
import { getRandomMessage, clickMessages } from '@/utils/clickMessages';
import { Progress } from "@/components/ui/progress";
import { Toggle } from "@/components/ui/toggle";
import { Music, VolumeX } from "lucide-react";

interface DegenButtonProps {
  onClick: () => void;
  isChaos: boolean;
}

const DegenButton: React.FC<DegenButtonProps> = ({ onClick, isChaos }) => {
  const [isPressed, setIsPressed] = useState(false);
  const [feedback, setFeedback] = useState('');
  const [clickStreak, setClickStreak] = useState(0);
  const [lastClickTime, setLastClickTime] = useState(0);
  const [progress, setProgress] = useState(0);
  const [isMusicPlaying, setIsMusicPlaying] = useState(false);
  const buttonRef = useRef<HTMLDivElement>(null);
  const clickSound = useRef<HTMLAudioElement | null>(null);
  const bgMusic = useRef<HTMLAudioElement | null>(null);
  
  useEffect(() => {
    clickSound.current = new Audio('/click.mp3');
    bgMusic.current = new Audio('/background-music.mp3');
    if (bgMusic.current) {
      bgMusic.current.loop = true;
      document.addEventListener('click', handleFirstInteraction, { once: true });
    }
    
    const totalClicks = parseInt(localStorage.getItem('degenClickCount') || '0', 10);
    const nextMilestone = Math.ceil(totalClicks / 1000) * 1000;
    setProgress((totalClicks % 1000) / 10);
    
    return () => {
      document.removeEventListener('click', handleFirstInteraction);
      if (bgMusic.current) {
        bgMusic.current.pause();
        bgMusic.current = null;
      }
    };
  }, []);
  
  const handleFirstInteraction = () => {
    if (bgMusic.current) {
      bgMusic.current.play().catch(e => console.log('Music play error:', e));
      setIsMusicPlaying(true);
    }
  };

  const handleClick = () => {
    setIsPressed(true);
    
    if (clickSound.current) {
      clickSound.current.currentTime = 0;
      clickSound.current.play().catch(e => console.log('Audio play error:', e));
    }
    
    const currentTime = Date.now();
    if (currentTime - lastClickTime < 2000) {
      setClickStreak(prev => prev + 1);
    } else {
      setClickStreak(1);
    }
    setLastClickTime(currentTime);
    
    setFeedback(getRandomMessage(clickMessages));
    onClick();
    
    const totalClicks = parseInt(localStorage.getItem('degenClickCount') || '0', 10) + 1;
    setProgress((totalClicks % 1000) / 10);
    
    setTimeout(() => {
      setIsPressed(false);
    }, 200);
    
    setTimeout(() => {
      setFeedback('');
    }, 3000);
  };

  const toggleMusic = () => {
    if (!bgMusic.current) return;
    
    if (isMusicPlaying) {
      bgMusic.current.pause();
    } else {
      bgMusic.current.play().catch(e => console.log('Music play error:', e));
    }
    setIsMusicPlaying(!isMusicPlaying);
  };

  return (
    <div className="flex flex-col items-center justify-center mb-10">
      <div className="w-full max-w-md mb-4 space-y-2">
        <div className="flex justify-between items-center text-green-500 font-vt323 text-lg">
          <span>Next Milestone</span>
          <span>{clickStreak > 1 ? `${clickStreak}x STREAK!` : ''}</span>
        </div>
        <Progress value={progress} className="h-2 bg-green-900">
          <div className="h-full bg-green-500 transition-all duration-500" />
        </Progress>
      </div>
      
      <Toggle
        className="mb-4 bg-green-900/20 hover:bg-green-900/40 text-green-500 font-vt323 space-x-2"
        pressed={isMusicPlaying}
        onPressedChange={toggleMusic}
      >
        {isMusicPlaying ? <Music size={20} className="mr-1" /> : <VolumeX size={20} className="mr-1" />}
        <span>Toggle Degen Vibes</span>
      </Toggle>
      
      <div
        ref={buttonRef}
        className={`degen-button w-64 h-64 md:w-80 md:h-80 text-xl md:text-2xl select-none mb-6 
                   transform transition-all duration-200 
                   ${isPressed ? 'pressed scale-95' : 'hover:scale-105'} 
                   ${isChaos ? 'animate-shake' : ''}`}
        onClick={handleClick}
        style={{
          transform: `perspective(1000px) rotateX(10deg) ${isChaos ? 'rotate(5deg)' : ''}`,
          background: 'linear-gradient(45deg, #9b87f5, #7E69AB)',
          border: '4px solid #6E59A5',
          borderRadius: '20px',
          boxShadow: `
            0 0 25px rgba(155, 135, 245, 0.5),
            0 0 45px rgba(155, 135, 245, 0.3),
            inset 0 0 20px rgba(155, 135, 245, 0.3)
          `,
          animation: 'pulse 2s infinite'
        }}
      >
        <div className="degen-button-top relative overflow-hidden
                      before:content-[''] before:absolute before:top-0 before:left-0 before:right-0 before:bottom-0
                      before:bg-gradient-to-b before:from-white/20 before:to-transparent before:opacity-50 hover:animate-pulse">
          <span className="z-20 select-none font-press-start text-center px-4 py-2 text-lg md:text-xl text-white drop-shadow-lg">
            DEGEN
          </span>
        </div>
      </div>
      
      {feedback && (
        <div className="h-8 mb-4">
          <p className="text-xl font-vt323 animate-bounce text-green-500">{feedback}</p>
        </div>
      )}
      
      {!feedback && <div className="h-8 mb-4"></div>}
    </div>
  );
};

export default DegenButton;
