
import React from 'react';
import { Badge } from "@/components/ui/badge";
import { AlertTriangle } from "lucide-react";

const BetaBanner = () => {
  return (
    <div className="fixed top-0 left-0 w-full bg-purple-900/50 border-b border-purple-500 py-2 px-4 z-50 animate-pulse">
      <div className="max-w-4xl mx-auto flex items-center justify-center gap-2 text-white font-vt323">
        <AlertTriangle className="h-4 w-4" />
        <span className="text-sm">BETA VERSION</span>
        <Badge variant="secondary" className="bg-purple-500 text-white">v0.1.0</Badge>
      </div>
    </div>
  );
};

export default BetaBanner;
