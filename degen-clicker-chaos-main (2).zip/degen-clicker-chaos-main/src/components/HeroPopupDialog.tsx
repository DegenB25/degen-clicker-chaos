
import React from "react";
import { Dialog, DialogContent } from "@/components/ui/dialog";

interface HeroPopupDialogProps {
  open: boolean;
  code: string;
  onOpenChange: (open: boolean) => void;
}

const HeroPopupDialog: React.FC<HeroPopupDialogProps> = ({ open, code, onOpenChange }) => (
  <Dialog open={open} onOpenChange={onOpenChange}>
    <DialogContent className="bg-black border-2 border-green-500 text-green-500 font-vt323 max-w-md flex flex-col items-center justify-center">
      <div className="py-4 px-2 text-center">
        <h3 className="text-2xl mb-2 flicker">Legendary! Your DEGEN CODE:</h3>
        <div className="bg-green-900/20 border border-green-500 p-4 mb-3">
          <span className="text-3xl font-mono tracking-wide">{code}</span>
        </div>
        <p className="mb-4">Share it on Twitter and tag <span className="text-blue-400">@degenbutton</span> for a chance to be featured.</p>
        <a
          className="inline-block bg-green-700 hover:bg-green-600 text-white py-2 px-6 rounded font-vt323 text-lg mt-2"
          style={{ letterSpacing: '0.05em', transition: 'background 0.2s' }}
          target="_blank"
          rel="noopener noreferrer"
          href={
            `https://twitter.com/intent/tweet?text=${encodeURIComponent(`I found my DEGEN CODE: ${code}! Try your luck: https://thedegenbutton.com @degenbutton`)}`
          }
        >
          Share on Twitter
        </a>
      </div>
    </DialogContent>
  </Dialog>
);

export default HeroPopupDialog;
