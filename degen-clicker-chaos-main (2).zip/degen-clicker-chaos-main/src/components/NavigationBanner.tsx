
import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
  navigationMenuTriggerStyle,
} from "@/components/ui/navigation-menu";

const NavigationBanner = () => {
  const location = useLocation();
  
  return (
    <div className="w-full bg-black border-b border-green-500 mb-4 sticky top-0 z-50">
      <div className="max-w-4xl mx-auto py-2 px-4">
        <NavigationMenu className="justify-center w-full">
          <NavigationMenuList>
            <NavigationMenuItem>
              <Link to="/">
                <NavigationMenuLink 
                  className={`${navigationMenuTriggerStyle()} text-green-500 hover:text-green-400 hover:bg-green-900/20 ${location.pathname === '/' ? 'bg-green-900/30' : ''}`}>
                  🏠 Home
                </NavigationMenuLink>
              </Link>
            </NavigationMenuItem>
            
            <NavigationMenuItem>
              <Link to="/lore">
                <NavigationMenuLink 
                  className={`${navigationMenuTriggerStyle()} text-green-500 hover:text-green-400 hover:bg-green-900/20 ${location.pathname === '/lore' ? 'bg-green-900/30' : ''}`}>
                  📜 The Lore
                </NavigationMenuLink>
              </Link>
            </NavigationMenuItem>
            
            <NavigationMenuItem>
              <Link to="/token">
                <NavigationMenuLink 
                  className={`${navigationMenuTriggerStyle()} text-green-500 hover:text-green-400 hover:bg-green-900/20 ${location.pathname === '/token' ? 'bg-green-900/30' : ''}`}>
                  💸 $CLICK Token
                </NavigationMenuLink>
              </Link>
            </NavigationMenuItem>
          </NavigationMenuList>
        </NavigationMenu>
      </div>
    </div>
  );
};

export default NavigationBanner;
