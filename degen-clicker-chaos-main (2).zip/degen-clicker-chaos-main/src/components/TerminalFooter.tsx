
import React from 'react';

const TerminalFooter: React.FC = () => {
  return (
    <div className="w-full max-w-lg mx-auto mt-auto">
      <div className="border-t border-green-600 pt-4 text-left">
        <p className="terminal-text terminal-line mb-1">You're part of the problem. We respect that.</p>
        <p className="terminal-text terminal-line mb-1">Twitter: @degenbutton</p>
        <p className="terminal-text terminal-line">Built on poor life choices.</p>
      </div>
    </div>
  );
};

export default TerminalFooter;
