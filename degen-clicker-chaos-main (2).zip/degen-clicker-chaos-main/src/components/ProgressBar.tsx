
import React from "react";

interface ProgressBarProps {
  clickCount: number;
}

const ProgressBar: React.FC<ProgressBarProps> = ({ clickCount }) => (
  <div className="w-full max-w-md mb-10 space-y-2">
    <div className="flex justify-between items-center text-green-500 font-vt323 text-lg">
      <span>Next chaos unlock at 1,000 clicks...</span>
      <span>{Math.floor(clickCount / 1000) * 1000 + 1000 - clickCount} more!</span>
    </div>
    <div className="h-4 bg-green-900/30 rounded-full overflow-hidden border border-green-500/50">
      <div
        className="h-full bg-green-500 transition-all duration-500 relative"
        style={{ width: `${(clickCount % 1000) / 10}%` }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-green-400/30 to-transparent animate-pulse"></div>
      </div>
    </div>
  </div>
);

export default ProgressBar;
