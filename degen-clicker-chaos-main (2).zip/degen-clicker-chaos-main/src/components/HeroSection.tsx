
import React from "react";

interface HeroSectionProps {
  onHeroTextClick: () => void; // Changed from (e: React.MouseEvent) => void to match Index.tsx
}

const HeroSection: React.FC<HeroSectionProps> = ({ onHeroTextClick }) => (
  <div className="mb-12 text-center">
    <h1
      className="text-4xl md:text-6xl font-press-start mb-2 glitch-text select-none cursor-pointer animate-pulse"
      data-text="THE DEGEN BUTTON"
      onClick={onHeroTextClick}
      tabIndex={0}
    >
      THE DEGEN BUTTON
    </h1>
    <h2 className="text-xl md:text-2xl font-vt323 mt-1 mb-2">
      Click. Brag. Repeat.<br />
      Join the Whitelist if You Survive.
    </h2>
    <p className="text-lg italic mt-2 opacity-80 font-vt323">
      "Every click matters. Or maybe it doesn't. You decide."
    </p>
  </div>
);

export default HeroSection;
