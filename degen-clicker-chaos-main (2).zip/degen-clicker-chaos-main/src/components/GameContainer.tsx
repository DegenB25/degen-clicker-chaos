
import React from 'react';
import DegenButton from '@/components/DegenButton';
import ClickCounter from '@/components/ClickCounter';
import ProgressBar from '@/components/ProgressBar';

interface GameContainerProps {
  clickCount: number;
  isGlitching: boolean;
  isChaos: boolean;
  buttonClickAnimation: boolean;
  onButtonClick: () => void;  // This is now correctly defined as () => void
}

const GameContainer: React.FC<GameContainerProps> = ({
  clickCount,
  isGlitching,
  isChaos,
  buttonClickAnimation,
  onButtonClick
}) => {
  return (
    <>
      <div className={buttonClickAnimation ? "animate-bounce scale-110" : ""} style={{ transition: 'transform 0.2s' }}>
        <DegenButton onClick={onButtonClick} isChaos={isChaos} />
      </div>

      <ProgressBar clickCount={clickCount} />
      <ClickCounter count={clickCount} isGlitching={isGlitching} />
    </>
  );
};

export default GameContainer;
