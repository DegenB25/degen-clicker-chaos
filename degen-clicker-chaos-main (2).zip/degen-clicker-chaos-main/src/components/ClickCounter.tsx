
import React, { useEffect, useState, useRef } from 'react';

interface ClickCounterProps {
  count: number;
  isGlitching: boolean;
}

const ClickCounter: React.FC<ClickCounterProps> = ({ count, isGlitching }) => {
  const [displayCount, setDisplayCount] = useState(count);
  const [isAnimating, setIsAnimating] = useState(false);
  const prevCount = useRef(count);
  
  // Format number with commas
  const formatNumber = (num: number): string => {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  };
  
  useEffect(() => {
    if (count !== prevCount.current) {
      setIsAnimating(true);
      setTimeout(() => {
        setDisplayCount(count);
        setIsAnimating(false);
      }, 300);
      prevCount.current = count;
    }
  }, [count]);

  return (
    <div className="flex flex-col items-center mb-10">
      <div className="flex items-center">
        <span className={`text-xl md:text-2xl font-vt323 ${isGlitching ? 'animate-glitch' : ''}`}>
          TOTAL CLICKS:
        </span>
        <div className="ml-2 overflow-hidden">
          <span 
            className={`text-2xl md:text-3xl font-vt323 inline-block
                      ${isAnimating ? 'animate-number-spin' : ''}
                      ${isGlitching ? 'animate-glitch' : ''}`}
            style={{ minWidth: '120px', textAlign: 'left' }}
          >
            [{formatNumber(displayCount)}]
          </span>
        </div>
      </div>
    </div>
  );
};

export default ClickCounter;
