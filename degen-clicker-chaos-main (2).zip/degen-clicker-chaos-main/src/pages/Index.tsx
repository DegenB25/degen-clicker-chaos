
import React, { useState, useEffect } from 'react';
import ChaosEvents from '@/components/ChaosEvents';
import TerminalFooter from '@/components/TerminalFooter';
import WhitelistForm from '@/components/WhitelistForm';
import DegenFortune from '@/components/DegenFortune';
import HeroSection from '@/components/HeroSection';
import DegenCodeDialog from '@/components/DegenCodeDialog';
import HeroPopupDialog from '@/components/HeroPopupDialog';
import BetaBanner from '@/components/BetaBanner';
import NewFeatures from '@/components/NewFeatures';
import GameContainer from '@/components/GameContainer';
import { useAudioControls } from '@/hooks/useAudioControls';
import { useClickHandling } from '@/hooks/useClickHandling';

const Index = () => {
  const [clickCount, setClickCount] = useState(0);
  const [isChaos, setIsChaos] = useState(false);
  const [isGlitching, setIsGlitching] = useState(false);
  const [showWhitelist, setShowWhitelist] = useState(false);
  const [showTerminalCode, setShowTerminalCode] = useState(false);
  const [degenCode, setDegenCode] = useState('');
  const [showFortune, setShowFortune] = useState(false);
  const [fortuneClickCount, setFortuneClickCount] = useState(0);
  const [showHeroPopup, setShowHeroPopup] = useState(false);
  const [heroPopupCode, setHeroPopupCode] = useState('');

  const { playMusic } = useAudioControls();

  const incrementClickCount = () => {
    setClickCount(prev => prev + 1);
    playMusic();
    const newCount = fortuneClickCount + 1;
    setFortuneClickCount(newCount);
    localStorage.setItem('fortuneClickCount', newCount.toString());
  };

  const {
    buttonClickAnimation,
    setButtonClickAnimation,
    handleHeroTextClick,
    handleButtonClick,
    handleMissClick,
  } = useClickHandling({
    setShowTerminalCode,
    setDegenCode,
    setHeroPopupCode,
    setShowHeroPopup,
    incrementClickCount,
  });

  useEffect(() => {
    const savedCount = localStorage.getItem('degenClickCount');
    const savedFortuneCount = localStorage.getItem('fortuneClickCount');

    if (savedCount) {
      setClickCount(parseInt(savedCount, 10));
      if (parseInt(savedCount, 10) >= 100) {
        setShowWhitelist(true);
      }
    }
    if (savedFortuneCount) {
      setFortuneClickCount(parseInt(savedFortuneCount, 10));
    }

    document.addEventListener('click', incrementClickCount);
    return () => document.removeEventListener('click', incrementClickCount);
  }, []);

  useEffect(() => {
    localStorage.setItem('degenClickCount', clickCount.toString());

    if (Math.random() > 0.8) {
      setIsGlitching(true);
      setTimeout(() => setIsGlitching(false), 500);
    }

    if (clickCount >= 100) {
      setShowWhitelist(true);
    }

    if (clickCount > 0 && clickCount % 1000 === 0) {
      setIsChaos(true);
    }

    if (clickCount > 0 && clickCount % 250 === 0) {
      setShowFortune(true);
      localStorage.setItem('fortuneClickCount', '0');
      setFortuneClickCount(0);
    }
  }, [clickCount]);

  useEffect(() => {
    if (buttonClickAnimation) {
      const timeout = setTimeout(() => setButtonClickAnimation(false), 600);
      return () => clearTimeout(timeout);
    }
  }, [buttonClickAnimation]);

  const handleChaosEnd = () => {
    setIsChaos(false);
  };

  const handleWhitelistSubmit = (email: string) => {
    console.log("Whitelist submission:", email);
    localStorage.setItem('whitelistEmail', email);
    setShowWhitelist(false);
  };

  return (
    <div className="retro-container" onClick={handleMissClick} style={{ minHeight: '100vh', overflow: 'auto' }}>
      <BetaBanner />
      <div className="scanline"></div>

      <HeroSection onHeroTextClick={handleHeroTextClick} />
      <NewFeatures />

      {showWhitelist && <WhitelistForm onSubmit={handleWhitelistSubmit} />}

      <GameContainer
        clickCount={clickCount}
        isGlitching={isGlitching}
        isChaos={isChaos}
        buttonClickAnimation={buttonClickAnimation}
        onButtonClick={handleButtonClick}
      />

      <ChaosEvents isActive={isChaos} onEnd={handleChaosEnd} />
      <DegenFortune open={showFortune} onOpenChange={setShowFortune} />
      <DegenCodeDialog open={showTerminalCode} code={degenCode} onOpenChange={setShowTerminalCode} />
      <HeroPopupDialog open={showHeroPopup} code={heroPopupCode} onOpenChange={setShowHeroPopup} />
      <TerminalFooter />
    </div>
  );
};

export default Index;
