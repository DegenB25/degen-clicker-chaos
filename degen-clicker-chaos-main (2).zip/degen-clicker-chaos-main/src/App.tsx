
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import Lore from "./pages/Lore";
import ClickToken from "./pages/ClickToken";
import NotFound from "./pages/NotFound";
import NavigationBanner from "./components/NavigationBanner";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <div className="min-h-screen">
        {/* Removed overflow-auto to let body handle scrolling naturally */}
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <NavigationBanner />
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/lore" element={<Lore />} />
            <Route path="/token" element={<ClickToken />} />
            {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </div>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
