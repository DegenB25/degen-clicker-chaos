
import { useRef, useEffect } from 'react';

export const useAudioControls = () => {
  const musicRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    musicRef.current = new Audio('/background-music.mp3');
    musicRef.current.loop = true;

    const tryPlayMusic = () => {
      if (musicRef.current) {
        musicRef.current.play().catch(() => {});
      }
    };
    document.addEventListener('pointerdown', tryPlayMusic, { once: true });

    return () => {
      document.removeEventListener('pointerdown', tryPlayMusic);
      if (musicRef.current) {
        musicRef.current.pause();
      }
    };
  }, []);

  const playMusic = () => {
    if (musicRef.current && musicRef.current.paused) {
      musicRef.current.play().catch(() => {});
    }
  };

  return { playMusic };
};
