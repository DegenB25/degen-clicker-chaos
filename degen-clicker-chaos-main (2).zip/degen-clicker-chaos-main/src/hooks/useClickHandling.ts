
import { useState } from 'react';
import { toast } from '@/hooks/use-toast';
import { missClickMessages, getRandomMessage, generateDegenCode } from '@/utils/clickMessages';

interface UseClickHandlingProps {
  setShowTerminalCode: (show: boolean) => void;
  setDegenCode: (code: string) => void;
  setHeroPopupCode: (code: string) => void;
  setShowHeroPopup: (show: boolean) => void;
  incrementClickCount: () => void;
}

export const useClickHandling = ({
  setShowTerminalCode,
  setDegenCode,
  setHeroPopupCode,
  setShowHeroPopup,
  incrementClickCount
}: UseClickHandlingProps) => {
  const [missClicks, setMissClicks] = useState(0);
  const [heroTextConsecutive, setHeroTextConsecutive] = useState(0);
  const [buttonClickAnimation, setButtonClickAnimation] = useState(false);

  const handleHeroTextClick = () => {
    setHeroTextConsecutive((prev) => {
      const newCount = prev + 1;
      if (newCount === 5) {
        const code = generateDegenCode();
        setHeroPopupCode(code);
        setShowHeroPopup(true);
        return 0;
      }
      return newCount;
    });
  };

  // Changed to remove the event parameter to match the expected signature in GameContainer
  const handleButtonClick = () => {
    incrementClickCount();
    setButtonClickAnimation(true);
    setHeroTextConsecutive(0);
  };

  const handleMissClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if ((e.target as HTMLElement).closest('.degen-button, form, a, button, [role="button"]')) return;
    
    setHeroTextConsecutive(0);
    setMissClicks(prev => {
      const newCount = prev + 1;
      if (newCount === 5) {
        const code = generateDegenCode();
        setDegenCode(code);
        setShowTerminalCode(true);
      } else {
        toast({
          description: getRandomMessage(missClickMessages),
          duration: 2000,
          className: "bottom-4 left-4 right-auto",
        });
      }
      return newCount;
    });
  };

  return {
    buttonClickAnimation,
    setButtonClickAnimation,
    handleHeroTextClick,
    handleButtonClick,
    handleMissClick,
  };
};
